<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Nền Tảng - Hành trang tới Tương lai</title>
</head>
<body>
    <h1>Nền Tảng - Hành trang tới Tương lai</h1>
    <h2>Danh sách các Khóa học</h2>
    <ul>
        <li><a href="/php/myhand">Thiết kế Web PHP & MySQL bằng PHP thuần</a></li>
        <li><a href="/php/twig">Thiết kế Web PHP & MySQL với Template Engine TWIG</a></li>
    </ul>
</body>
</html>