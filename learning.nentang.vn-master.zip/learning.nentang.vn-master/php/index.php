<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Nền tảng - cơ bản về học lập trình WEB</title>
</head>
<body>
    <h1>Xin chào các bạn!</h1>
    <h3>Nền tảng cung cấp cho các bạn kiến thức cơ bản về lập trình web. Hy vọng các bạn có được một hành trang tốt hướng dến tương lai!</h3>
    <h5>Good luck & Have fun!</h5>
</body>
</html>