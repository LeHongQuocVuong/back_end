<?php
    // silence is golden
    // Im lặng là vàng
?>