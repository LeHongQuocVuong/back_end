# Tổng quan Hệ thống
## Video demo
## Screenshots

# Nghiệp vụ
1. Quy trình Nghiệp vụ
2. Các biểu mẫu / báo cáo liên quan

# Thiết kế Database
1. Đáp ứng được các Nghiệp vụ nói trên.

# Danh sách các Chức năng Hệ thống
## Backend
1. Quản lý Tài khoản
- Rảng buộc dữ liệu trước khi Thêm / Sửa.
- Cảnh báo khi Xóa.
2. Quản lý Vai trò
3. Xác thực - Phân quyền
- Cấp Người dùng vào Vai trò cụ thể
- Cấp Người dùng Quyền chức năng Hệ thống
4. Code các chức năng Danh mục: 
- Xem, Thêm, Sửa, Xóa
- Mẫu In ấn (HTML print)
- Export dữ liệu (PDF, Excel)
- Import dữ liệu (từ Excel)
5. Quản lý Đơn hàng
6. Tạo các Báo cáo

## Frontend
1. Trang chủ
2. Giới thiệu
3. Liên hệ
4. Danh sách Sản phẩm
5. Sản phẩm chi tiết
6. Tìm kiếm Sản phẩm
7. Giỏ hàng
8. Thanh toán
9. Quản lý Tài khoản Khách hàng
- Hiệu chỉnh Thông tin Cá nhân (Họ tên / Email / SĐT; Mật khẩu; ...)
- Xem Giỏ hàng
- Xem lịch sử thanh toán.

# Workflow xử lý
```mermaid
a -> b
```