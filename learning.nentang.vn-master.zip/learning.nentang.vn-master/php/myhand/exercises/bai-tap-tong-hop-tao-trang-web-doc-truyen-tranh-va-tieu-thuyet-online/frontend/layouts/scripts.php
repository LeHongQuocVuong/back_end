<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="/php/myhand/exercises/bai-tap-tong-hop-tao-trang-web-doc-truyen-tranh-va-tieu-thuyet-online/assets/vendor/jquery/jquery.min.js"></script>
<script src="/php/myhand/exercises/bai-tap-tong-hop-tao-trang-web-doc-truyen-tranh-va-tieu-thuyet-online/assets/vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Thư viện Jquery validation -->
<script src="/php/myhand/exercises/bai-tap-tong-hop-tao-trang-web-doc-truyen-tranh-va-tieu-thuyet-online/assets/vendor/jquery-validation/jquery.validate.min.js"></script>
<script src="/php/myhand/exercises/bai-tap-tong-hop-tao-trang-web-doc-truyen-tranh-va-tieu-thuyet-online/assets/vendor/jquery-validation/localization/messages_vi.min.js"></script>