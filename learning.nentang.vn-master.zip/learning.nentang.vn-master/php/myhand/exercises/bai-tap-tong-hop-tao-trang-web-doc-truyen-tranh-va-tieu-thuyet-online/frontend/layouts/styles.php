<!-- Bootstrap CSS -->
<link rel="stylesheet" href="/php/myhand/exercises/bai-tap-tong-hop-tao-trang-web-doc-truyen-tranh-va-tieu-thuyet-online/assets/vendor/bootstrap/css/bootstrap.min.css" type="text/css" />
<!-- Font awesome -->
<link rel="stylesheet" href="/php/myhand/exercises/bai-tap-tong-hop-tao-trang-web-doc-truyen-tranh-va-tieu-thuyet-online/assets/vendor/font-awesome/css/font-awesome.min.css" type="text/css" />

<!-- Custom css - Các file css do chúng ta tự viết -->
<link rel="stylesheet" href="/php/myhand/exercises/bai-tap-tong-hop-tao-trang-web-doc-truyen-tranh-va-tieu-thuyet-online/assets/frontend/css/style.css" type="text/css" />