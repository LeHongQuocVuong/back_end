# Bài tập Tổng hợp
## Yêu cầu
Tạo trang phục vụ nhu cầu đọc Truyện Online cho các lứa tuổi.

Có 2 thể loại truyện chính có thể phục vụ:
- `Truyện tranh`: 


## Cấu trúc lưu trữ TRUYỆN TRANH:
```
Cấu trúc lưu trữ TRUYỆN TRANH:
- 1 Truyện Tranh
  - Có nhiều Tập
    - Trong 1 Tập có nhiều Hình ảnh
```

## Cấu trúc lưu trữ TIỂU THUYẾT:
```
Cấu trúc lưu trữ TIỂU THUYẾT:
- 1 Tiểu thuyết
  - Có nhiều Chương
    - Trong 1 Chương có nhiều Nội dung chữ
```

