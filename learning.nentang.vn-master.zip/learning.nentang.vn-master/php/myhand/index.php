<?php
    echo '<h1>Chào mừng các bạn đến với <a href="https://nentang.vn">Nền Tảng - Hành trang tới Tương lai!</a></h1>';
?>

<ul>
    <li><a href="backend/">Trang chủ Backend</a></li>
    <li><a href="frontend/">Trang chủ Frontend</a></li>
</ul>