<?php
    header('location:pages/dashboard.php');
?>