<?php
class StaticData {
    public static $PERMISSION_BACKEND_VIEW = 'backend-view';

    public static $PERMISSION_BACKEND_SHOP_SUPPLIERS_VIEW   = 'backend-shop-suppliers-view';
    public static $PERMISSION_BACKEND_SHOP_SUPPLIERS_CREATE = 'backend-shop-suppliers-create';
    public static $PERMISSION_BACKEND_SHOP_SUPPLIERS_EDIT   = 'backend-shop-suppliers-edit';
    public static $PERMISSION_BACKEND_SHOP_SUPPLIERS_DELETE = 'backend-shop-suppliers-delete';

    
}
