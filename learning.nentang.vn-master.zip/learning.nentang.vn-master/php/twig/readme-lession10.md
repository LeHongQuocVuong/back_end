# Ràng buộc dữ liệu (Validation)
## Lưu đồ hoạt động của quá trình Validate dữ liệu từ Client đến Server
[![../../assets/php/twig/ValidateWorkFlow.png](../../assets/php/twig/ValidateWorkFlow.png)](../../assets/php/twig/ValidateWorkFlow.png)

# Bài học trước
[Bài học 9](./readme-lession9.md)