# Tạo chức năng Đăng ký (Register) Backend




## Kiểm tra ứng dụng
- Truy cập địa chỉ: [http://learning.nentang.vn/php/twig/backend/pages/login.php](http://learning.nentang.vn/php/twig/backend/pages/login.php)

# Bài học trước
[Bài học 8](./readme-lession8.md)

# Bài học tiếp theo
[Bài học 10](./readme-lession10.md) 