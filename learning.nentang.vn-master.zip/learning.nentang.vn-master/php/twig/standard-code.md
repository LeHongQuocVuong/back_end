# Tiêu chuẩn coding

Các nút được đặt tên Id như sau:
- `btnSave`: nút Lưu dữ liệu, có thao tác Thực thi câu lệnh (execute query) SQL (INSERT / UPDATE statement)
- `btnDelete`: nút Xóa dữ liệu, có thao tác Thực thi câu lệnh (execute query) SQL (DELETE statement)
- `btnCreate`: nút hiển thị Form nhập liệu, dùng cho Thêm mới dữ liệu
- `btnEdit`: nút hiển thị Form nhập liệu, dùng cho Hiệu chỉnh dữ liệu (có binding / set lại giá trị cũ của dòng dữ liệu cần hiệu chỉnh)
